
package exe.bplus_tree;

import exe.*;
import java.io.*;
import java.lang.*;
import java.util.*;

public class bplus_tree{
    public static void main(String args[]) throws IOException {
    	Hashtable hash = XMLParameterParser.parseToHash(args[2]);

    	String[] params = new String[2];

    	params[0] = args[0] + ".sho";
    	params[1] = (String)hash.get("Enter the order of the tree (a value between 0 and 4) ");

    	BPlusTree.main(params);
    }
}
