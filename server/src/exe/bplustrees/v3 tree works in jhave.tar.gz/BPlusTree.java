/****************************************************************************************
 * BPlusTree.java
 * B+ Tree Visualization
 *
 *
 * @author William Clements
 * @version March 16 2010
 ***************************************************************************************/
package exe.bplus_tree;

import java.io.*;
import java.util.*;
import java.net.*;
import org.jdom.*;
import exe.*;
import exe.pseudocode.*;

public class BPlusTree {

    static TreeNode root;
    static final String TITLE = null;
    static final String FILE = "exe/bplus_tree/template.xml";
    static int order = 4;
    static GAIGStree visualTree;
    static GAIGSarray items;
    static PseudoCodeDisplay pseudo;
    static ShowFile show;

    public static void main(String args[]) throws IOException {
        // show file creation for the client
        ShowFile show = new ShowFile(args[0]);

        // Set restrictions on how wide the tree will be
        if (0 < Integer.parseInt(args[1]) && Integer.parseInt(args[1]) < 5)
          order = Integer.parseInt(args[1]);
        else
          order = 4;

        // declare
        visualTree = new GAIGStree(true, "B+ Tree    order "+order, "#000000", 0.1, 0.1, 0.9, 0.9, 0.07);
        root = new TreeNode();
        root.setHexColor("#3771c8");
        visualTree.setRoot(root);
        root.setValue("2");

        //setup the pseudo code display panel
        try {
            pseudo = new PseudoCodeDisplay(FILE);
        } catch (JDOMException e) {
            e.printStackTrace();
        }

        // initialize tree
        show.writeSnap(TITLE, doc_uri(4), make_uri(-1, -1, 0, PseudoCodeDisplay.RED), visualTree);
        TreeNode lc = new TreeNode("1");
        lc.setHexColor("#eeeeff");
        root.insertLeftChild(lc); 
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);
        TreeNode rc = new TreeNode("3");
        rc.setHexColor("#eeeeff");
        root.insertRightChild(rc);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 2, PseudoCodeDisplay.RED), visualTree);

//    Random rand = new Random();
//        BPlusTree tree = new BPlusTree();
//    for (int i=0; i<5; i++) {
//      tree.insert(i+1);//rand.nextInt());
//    }

        show.close();
    }

    private static String make_uri(int pass, int i, int line, int color) {
        return make_uri(pass, i, new int[]{line}, new int[]{color});
    }

    private static String make_uri(int pass, int i, int[] lines, int[] colors) {
        String passVal = pass == -1 ? "null" : String.valueOf(pass);
        String iVal = i == -1 ? "null" : String.valueOf(i);
        String stack = "main program\n"+"  insert(integer)";

        HashMap<String, String> map = new HashMap<String, String>();
        map.put("s", stack);
      	map.put("i", iVal);
      	map.put("s", stack);

        String uri = null;
        try {
            uri = pseudo.pseudo_uri(map, lines, colors);
        } catch (JDOMException e) {
            e.printStackTrace();
        }

        return uri;
    }

    // Return an appropriate inline string for the info page
    private static String doc_uri(int num_items) {

        String content = "<html><head><title>B+ Tree</title></head><body><h1>B+ Tree</h1></body></html>";
        URI uri = null;
        try {
            uri = new URI("str", content, "");
        } catch (java.net.URISyntaxException e) {
        }
        return uri.toASCIIString();
    }

    /**  
    public BPlusTree() {
    }

    public BPlusTree(Integer[] numberArray) throws IOException {
        for (int i = 0; i < numberArray.length; i++) {
            insert(numberArray[i]);
        }
    }

    public boolean insert(Integer obj) throws IOException {
        //modify the visual tree
        //visualTree.setRoot(root);
        show.writeSnap(TITLE, doc_uri(0), make_uri(-1, -1, 1, PseudoCodeDisplay.RED), items);

        TreeNode parent = null;
        TreeNode current = root;

        if (root == null) {
            root = new TreeNode(obj);
        } else {
            //modify the visual tree
            //visualTree.setRoot(root);
            show.writeSnap(TITLE, doc_uri(0), make_uri(-1, -1, 3, PseudoCodeDisplay.RED), items);

            //traverse down to the leaf
            int index = 0;
            while (current != null) {

                // look through the index set in a node
                index = 0;

                while (obj > current.indexSet.get(index) && index < current.indexSet.size() - 1) {
                    index++;
                }

                //searching down the tree, choose a direction
                parent = current;

                if (obj >= parent.indexSet.get(index)) {
                    current = parent.pointerList.get(index + 1);
                } else //go to the left
                {
                    current = parent.pointerList.get(index);
                }
            }

            //modify the visual tree
            //visualTree.setRoot(root);
            show.writeSnap(TITLE, doc_uri(0), make_uri(-1, -1, 5, PseudoCodeDisplay.RED), items);

            //at this point parent is at a leaf node
            if (parent.indexSet.get(index) != obj) {
                //modify the visual tree
                //visualTree.setRoot(root);
                show.writeSnap(TITLE, doc_uri(0), make_uri(-1, -1, 6, PseudoCodeDisplay.RED), items);

                if (parent.indexSet.size() < order) { // there is room to insert number in the leaf
                    //modify the visual tree
                    //visualTree.setRoot(root);
                    show.writeSnap(TITLE, doc_uri(0), make_uri(-1, -1, 7, PseudoCodeDisplay.RED), items);

                    parent.addToNode(obj, null);
                } else { //the leaf must be split after insertion. leaf size cannot = order.
                    //modify the visual tree
                    //visualTree.setRoot(root);
                    show.writeSnap(TITLE, doc_uri(0), make_uri(-1, -1, 9, PseudoCodeDisplay.RED), items);

                    parent.addToNode(obj, null);
                    split(parent);
                }

                //modify the visual tree
                //visualTree.setRoot(root);
                show.writeSnap(TITLE, doc_uri(0), make_uri(-1, -1, 0, PseudoCodeDisplay.RED), items);
            } else {
                //modify the visual tree
                //visualTree.setRoot(root);
                show.writeSnap(TITLE, doc_uri(0), make_uri(-1, -1, 12, PseudoCodeDisplay.RED), items);

                return false; // The integer to be inserted already exists.
            }

        }

        //test print of the root
        System.out.print("current root view: ");
        for (int i = 0; i < root.indexSet.size(); i++) {
            System.out.print(root.indexSet.get(i) + " ");
        }
        System.out.println();

        return true;
    }

    public void split(TreeNode currentNodeToBeSplit) throws IOException {
        if (currentNodeToBeSplit.pointerList.get(0) == null) { //spliting a leaf

            //Find the median
            int medianIndex = (int) Math.ceil(((double) currentNodeToBeSplit.indexSet.size()) / 2.0);

            int median = currentNodeToBeSplit.indexSet.get(medianIndex);

            //Make a new leaf node. put the median and all the numbers > the median in this node
            TreeNode newLeafNode = new TreeNode(currentNodeToBeSplit.indexSet.remove(medianIndex));
            currentNodeToBeSplit.pointerList.remove(medianIndex);
            newLeafNode.parentPointer = currentNodeToBeSplit.parentPointer;
            newLeafNode.rightLeaf = currentNodeToBeSplit.rightLeaf;
            newLeafNode.leftLeaf = currentNodeToBeSplit;
            if (newLeafNode.rightLeaf != null) {
                newLeafNode.rightLeaf.leftLeaf = newLeafNode;
            }
            while (currentNodeToBeSplit.indexSet.size() > medianIndex) {
                newLeafNode.addToNode(currentNodeToBeSplit.indexSet.remove(medianIndex), null);
                currentNodeToBeSplit.pointerList.remove(medianIndex);
            }

            //Fix the pointers of the leaf that was split
            currentNodeToBeSplit.rightLeaf = newLeafNode;

            if (currentNodeToBeSplit.parentPointer == null) { //a new node is made at the root
                TreeNode newParentNode = new TreeNode(newLeafNode.indexSet.get(0));
                newParentNode.pointerList.set(0, currentNodeToBeSplit);
                newParentNode.pointerList.set(1, newLeafNode);
                currentNodeToBeSplit.parentPointer = newParentNode;
                root = newParentNode;
            } else { // a parent exist. pass a number up to the parent
                currentNodeToBeSplit.parentPointer.addToNode(newLeafNode.indexSet.get(0), newLeafNode);
                if (currentNodeToBeSplit.parentPointer.indexSet.size() == order) {
                    split(currentNodeToBeSplit.parentPointer);
                }
            }

        } else { //spliting a node

            //Find the median
            int medianIndex = (int) Math.ceil(((double) currentNodeToBeSplit.indexSet.size()) / 2.0);

            int median = currentNodeToBeSplit.indexSet.get(medianIndex);

            //Make a new node. put the median and all the numbers > the median in this node
            TreeNode newNodeOnTheRight = new TreeNode(currentNodeToBeSplit.indexSet.remove(medianIndex));
            currentNodeToBeSplit.pointerList.remove(medianIndex);
            newNodeOnTheRight.parentPointer = currentNodeToBeSplit.parentPointer;
            newNodeOnTheRight.rightLeaf = null;
            newNodeOnTheRight.leftLeaf = null;
            while (currentNodeToBeSplit.indexSet.size() > medianIndex) {
                newNodeOnTheRight.addToNode(currentNodeToBeSplit.indexSet.remove(medianIndex), null);
                currentNodeToBeSplit.pointerList.remove(medianIndex);
            }

            currentNodeToBeSplit.rightLeaf = null;
            currentNodeToBeSplit.leftLeaf = null;

            if (currentNodeToBeSplit.parentPointer == null) { //a new node is made at the root
                TreeNode newParentNode = new TreeNode(newNodeOnTheRight.indexSet.get(0));
                newParentNode.pointerList.set(0, currentNodeToBeSplit);
                newParentNode.pointerList.set(1, newNodeOnTheRight);
                currentNodeToBeSplit.parentPointer = newParentNode;
                root = newParentNode;
            } else { // a parent exist. pass a number up to the parent
                currentNodeToBeSplit.parentPointer.addToNode(newNodeOnTheRight.indexSet.get(0), newNodeOnTheRight);
                if (currentNodeToBeSplit.parentPointer.indexSet.size() == order) {
                    split(currentNodeToBeSplit.parentPointer);
                }
            }

        }

        //modify the visual tree
        //visualTree.setRoot(root);
        show.writeSnap(TITLE, doc_uri(0), make_uri(-1, -1, 10, PseudoCodeDisplay.RED), items);

        return;
    }
    public ArrayList wholeTree;

    public String printTree() {

        //find depth
        int level = 0;
        TreeNode tempNode = root;
        wholeTree = new ArrayList<String>();

        while (tempNode != null) {
            wholeTree.add(level, "");
            tempNode = tempNode.pointerList.get(0);
            level++;
        }
        System.out.println("levels present: " + level);

        ArrayList<String> treeArray = printTree(root, 0);

        String rtnStr = "";
        for (int i = 0; i < treeArray.size(); i++) {
            rtnStr += treeArray.get(i) + "\n";
        }
        return rtnStr;
    }

    public ArrayList<String> printTree(TreeNode node, int level) {

        for (int j = 0; j < node.indexSet.size(); j++) { //store all the integers in an array

            wholeTree.set(level, "" + wholeTree.get(level) + node.indexSet.get(j) + " ");
            if (node.pointerList.get(j) != null) //go down the tree
            {
                printTree(node.pointerList.get(j), level + 1);
            }

        }
        //visit the last pointer on the end of the interior node
        if (node.pointerList.get(node.indexSet.size()) != null) {
            printTree(node.pointerList.get(node.indexSet.size()), level + 1);
        }

        wholeTree.set(level, "" + wholeTree.get(level) + " | ");

        return wholeTree;
    }

    private static class TreeNode {

        ArrayList<Integer> indexSet = new ArrayList<Integer>(); //contain integers
        ArrayList<TreeNode> pointerList = new ArrayList<TreeNode>();
        TreeNode parentPointer;
        //right and left leaf pointers are for the leaves
        TreeNode leftLeaf;
        TreeNode rightLeaf;

        public TreeNode(Integer obj) { //the first integer that goes into the root
            parentPointer = null;
            indexSet.add(obj);
            pointerList.add(null);
            pointerList.add(null);
            leftLeaf = null;
            rightLeaf = null;
        }

        public String toString() {
            String returnString = "";
            for (int i = 0; i < indexSet.size(); i++) {
                returnString += indexSet.get(i) + " ";
            }
            return returnString;
        }

        public boolean addToNode(Integer obj, TreeNode rightLeafPointer) {

            //linear search. add the number into the list
            for (int i = 0; i < indexSet.size(); i++) {
                if (obj < indexSet.get(i)) {
                    int temp = indexSet.get(i);
                    TreeNode tempNode = pointerList.get(i + 1);

                    indexSet.set(i, obj);
                    pointerList.set(i, rightLeafPointer);

                    obj = temp;
                    rightLeafPointer = tempNode;
                }
            }

            indexSet.add(obj);
            pointerList.add(rightLeafPointer);

            return true;
        }
    }
    */
}
