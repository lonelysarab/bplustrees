/****************************************************************************************
 * BPT.java
 * holds the tree and nodes
 *
 *
 * @author William Clements
 * @version May 15 2010
 ***************************************************************************************/

package exe.bplus_tree;
import java.io.*;

import java.util.*;
import exe.pseudocode.*;

public class BPT {

    static BTNode root;
    static int order;

    /**  */
    public BPT() {
    }

    /**  */
    public BPT(Integer[] numberArray) throws IOException {
      for (int i = 0; i < numberArray.length; i++)
        insert(numberArray[i]);
    }

    /**  */
    public boolean insert(Integer obj) throws IOException {

      BTNode parent = null;
      BTNode current = root;

      if (root == null) {
        root = new BTNode(obj); 

        //modify the visual tree
        BPlusTree.JHAVEroot.setValue(""+obj);
        BPlusTree.JHAVEroot.setHexColor("#eeeeff");
        BPlusTree.show.writeSnap(BPlusTree.TITLE, BPlusTree.doc_uri(4), BPlusTree.make_uri(1, 1, 1, PseudoCodeDisplay.RED), BPlusTree.visualTree);

      }
      else {

        //traverse down to the leaf
        int index = 0;
        while (current != null) {

          // look through the index set in a node
          index = 0;

          while(obj > current.indexSet.get(index) && index < current.indexSet.size()-1) {
            index++;
          }

          //searching down the tree, choose a direction
          parent = current;

          if(obj >= parent.indexSet.get(index))
            current = parent.pointerList.get(index+1);
          else //go to the left
            current = parent.pointerList.get(index);
        }

        //at this point parent is at a leaf node

        if (parent.indexSet.get(index) != obj) {
          if (parent.indexSet.size() < order) // there is room to insert number in the leaf
            parent.addToNode(obj,null);
          else { //the leaf must be split after insertion. leaf size cannot = order.
            parent.addToNode(obj,null);          
            split(parent);
          }

          //modify the visual tree
          BPlusTree.JHAVEroot.setValue(""+obj);
          BPlusTree.JHAVEroot.setHexColor("#eeeeff");
          BPlusTree.show.writeSnap(BPlusTree.TITLE, BPlusTree.doc_uri(4), BPlusTree.make_uri(1, 1, 1, PseudoCodeDisplay.RED), BPlusTree.visualTree);
        }
        else 
          return false; // The integer to be inserted already exists.

      }

      //test print of the root
      System.out.print("current root view: ");
      for(int i=0; i<root.indexSet.size(); i++)
        System.out.print(root.indexSet.get(i)+" ");
      System.out.println();

      return true; 
    }

    public void split(BTNode currentNodeToBeSplit) {
      if (currentNodeToBeSplit.pointerList.get(0) == null) { //spliting a leaf 

        //Find the median
        int medianIndex=(int)Math.ceil(((double)currentNodeToBeSplit.indexSet.size())/2.0);

        int median = currentNodeToBeSplit.indexSet.get(medianIndex);

        //Make a new leaf node. put the median and all the numbers > the median in this node
        BTNode newLeafNode = new BTNode(currentNodeToBeSplit.indexSet.remove(medianIndex));
        currentNodeToBeSplit.pointerList.remove(medianIndex);
        newLeafNode.parentPointer = currentNodeToBeSplit.parentPointer;
        newLeafNode.rightLeaf = currentNodeToBeSplit.rightLeaf;
        newLeafNode.leftLeaf = currentNodeToBeSplit;
        if (newLeafNode.rightLeaf != null)
          newLeafNode.rightLeaf.leftLeaf = newLeafNode;
        while(currentNodeToBeSplit.indexSet.size() > medianIndex) {
          newLeafNode.addToNode(currentNodeToBeSplit.indexSet.remove(medianIndex),null);
          currentNodeToBeSplit.pointerList.remove(medianIndex);
        }

        //Fix the pointers of the leaf that was split
        currentNodeToBeSplit.rightLeaf = newLeafNode;

        if (currentNodeToBeSplit.parentPointer == null) { //a new node is made at the root
          BTNode newParentNode = new BTNode(newLeafNode.indexSet.get(0));
          newParentNode.pointerList.set(0,currentNodeToBeSplit);
          newParentNode.pointerList.set(1,newLeafNode);
          currentNodeToBeSplit.parentPointer = newParentNode;
          root = newParentNode;
        }
        else { // a parent exist. pass a number up to the parent
          currentNodeToBeSplit.parentPointer.addToNode(newLeafNode.indexSet.get(0),newLeafNode);
          if (currentNodeToBeSplit.parentPointer.indexSet.size() == order)
            split(currentNodeToBeSplit.parentPointer);
        }

      }
      else { //spliting a node
        
        //Find the median
        int medianIndex=(int)Math.ceil(((double)currentNodeToBeSplit.indexSet.size())/2.0);

        int median = currentNodeToBeSplit.indexSet.get(medianIndex);

        //Make a new node. put the median and all the numbers > the median in this node
        BTNode newNodeOnTheRight = new BTNode(currentNodeToBeSplit.indexSet.remove(medianIndex));
        currentNodeToBeSplit.pointerList.remove(medianIndex);
        newNodeOnTheRight.parentPointer = currentNodeToBeSplit.parentPointer;
        newNodeOnTheRight.rightLeaf = null;
        newNodeOnTheRight.leftLeaf = null;
        while(currentNodeToBeSplit.indexSet.size() > medianIndex) {
          newNodeOnTheRight.addToNode(currentNodeToBeSplit.indexSet.remove(medianIndex),null);
          currentNodeToBeSplit.pointerList.remove(medianIndex);
        }

        currentNodeToBeSplit.rightLeaf = null;
        currentNodeToBeSplit.leftLeaf = null;

        if (currentNodeToBeSplit.parentPointer == null) { //a new node is made at the root
          BTNode newParentNode = new BTNode(newNodeOnTheRight.indexSet.get(0));
          newParentNode.pointerList.set(0,currentNodeToBeSplit);
          newParentNode.pointerList.set(1,newNodeOnTheRight);
          currentNodeToBeSplit.parentPointer = newParentNode;
          root = newParentNode;
        }
        else { // a parent exist. pass a number up to the parent
          currentNodeToBeSplit.parentPointer.addToNode(newNodeOnTheRight.indexSet.get(0),newNodeOnTheRight);
          if (currentNodeToBeSplit.parentPointer.indexSet.size() == order)
            split(currentNodeToBeSplit.parentPointer);
        }

      }

      return;
    } 

    public ArrayList wholeTree;


    public static class BTNode {
      ArrayList<Integer> indexSet = new ArrayList<Integer>(); //contain integers
      ArrayList<BTNode> pointerList = new ArrayList<BTNode>(); 
      BTNode parentPointer;
      
      //right and left leaf pointers are for the leaves
      BTNode leftLeaf;
      BTNode rightLeaf;

      public BTNode(Integer obj) { //the first integer that goes into the root
        parentPointer = null;
        indexSet.add(obj);
        pointerList.add(null);
        pointerList.add(null);
        leftLeaf = null;
        rightLeaf = null;
      }

      public String toString() {
        String returnString = "";
        for (int i=0; i<indexSet.size(); i++)
          returnString += indexSet.get(i)+" ";
        return returnString; 
      }

      public boolean addToNode(Integer obj, BTNode rightLeafPointer) {

        //linear search. add the number into the list
        for(int i = 0; i < indexSet.size(); i++)
        {
          if (obj < indexSet.get(i) ) {
            int temp = indexSet.get(i);
            BTNode tempNode = pointerList.get(i+1);

            indexSet.set(i,obj);
            pointerList.set(i,rightLeafPointer);
            
            obj = temp;
            rightLeafPointer = tempNode;
          }
        }

        indexSet.add(obj);
        pointerList.add(rightLeafPointer);

        return true;
      }

  }

}



