/****************************************************************************************
 * BPlusTree.java
 * B+ Tree Visualization
 *
 *
 * @author William Clements
 * @version March 16 2010
 ***************************************************************************************/
package exe.bplus_tree;

import java.io.*;
import java.lang.*;
import java.util.*;

import java.net.*;
import org.jdom.*;
import exe.*;
import exe.pseudocode.*;

public class BPlusTree {

    //for JHAVE
    static TreeNode JHAVEroot;
    static final String TITLE = null;
    static final String FILE = "exe/bplus_tree/template.xml";
    static GAIGSb_plus_tree visualTree;
    static PseudoCodeDisplay pseudo;
    static ShowFile show;
    static int order = 4;

    public static void main(String args[]) throws IOException {
        // show file creation for the client
        show = new ShowFile(args[0]);

        // Set restrictions on how wide the tree will be
        if (0 < Integer.parseInt(args[1]) && Integer.parseInt(args[1]) < 5) {
          order = Integer.parseInt(args[1]);
          BPT.order = Integer.parseInt(args[1]);
        }
        else {
          order = 4;
          BPT.order = 4;
        }

        // declare a new tree in JHAVE
        visualTree = new GAIGSb_plus_tree(false, "B+ Tree    order "+order, "#000000", 0.1, 0.1, 0.9, 0.9, 0.07);

        //setup the pseudo code display panel
        try {
            pseudo = new PseudoCodeDisplay(FILE);
        } catch (JDOMException e) {
            e.printStackTrace();
        }

        // initialize tree
//        Integer[] tempIntArray = {6,8,5,7,4};
//        BPT tree = new BPT(tempIntArray);

        //make the root
        JHAVEroot = new TreeNode();
        visualTree.setRoot(JHAVEroot);

        //assign a value to the root
        JHAVEroot.setValue("3");
        JHAVEroot.setHexColor("#eeeeff");
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        //make siblings 
        TreeNode tempNode = new TreeNode();
        tempNode.setValue("12");
        tempNode.setHexColor("#eeeeff");
        JHAVEroot.setChildWithEdge(tempNode);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        TreeNode tempNodetwo = new TreeNode();
        tempNodetwo.setValue("8");
        tempNodetwo.setHexColor("#eeeeff");
        JHAVEroot.setChildWithEdge(tempNodetwo);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        TreeNode tempNodeThree = new TreeNode();
        tempNodeThree.setValue("9");
        tempNodeThree.setHexColor("#eeeeff");
        JHAVEroot.setChildWithEdge(tempNodeThree);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        TreeNode tempNodeFour = new TreeNode();
        tempNodeFour.setValue("10");
        tempNodeFour.setHexColor("#eeeeff");
        JHAVEroot.setChildWithEdge(tempNodeFour);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        TreeNode tempNodeFive = new TreeNode();
        tempNodeFive.setValue("11");
        tempNodeFive.setHexColor("#eeeeff");
        JHAVEroot.setChildWithEdge(tempNodeFive);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);


/*
        TreeNode lc = new TreeNode("1");
        lc.setHexColor("#eeeeff");
        JHAVEroot.insertLeftChild(lc); 
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);
        TreeNode rc = new TreeNode("3");
        rc.setHexColor("#eeeeff");
        JHAVEroot.insertRightChild(rc);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);
*/    
        show.close();
    }


    public static String make_uri(int pass, int i, int line, int color) {
        return make_uri(pass, i, new int[]{line}, new int[]{color});
    }

    public static String make_uri(int pass, int i, int[] lines, int[] colors) {
        String passVal = pass == -1 ? "null" : String.valueOf(pass);
        String iVal = i == -1 ? "null" : String.valueOf(i);
        String stack = "main program\n"+"  insert(integer)";

        HashMap<String, String> map = new HashMap<String, String>();
        map.put("s", stack);
      	map.put("i", iVal);
      	map.put("s", stack);

        String uri = null;
        try {
            uri = pseudo.pseudo_uri(map, lines, colors);
        } catch (JDOMException e) {
            e.printStackTrace();
        }

        return uri;
    }

    // Return an appropriate inline string for the info page
    public static String doc_uri(int num_items) {

        String content = "<html><head><title>B+ Tree</title></head><body><h1>B+ Tree</h1></body></html>";
        URI uri = null;
        try {
            uri = new URI("str", content, "");
        } catch (java.net.URISyntaxException e) {
        }
        return uri.toASCIIString();
    }

/*
    public String printTree() {

        //find depth
        int level = 0;
        BTNode tempNode = root;
        wholeTree = new ArrayList<String>();

        while (tempNode != null) {
            wholeTree.add(level, "");
            tempNode = tempNode.pointerList.get(0);
            level++;
        }
        System.out.println("levels present: " + level);

        ArrayList<String> treeArray = printTree(root, 0);

        String rtnStr = "";
        for (int i = 0; i < treeArray.size(); i++) {
            rtnStr += treeArray.get(i) + "\n";
        }
        return rtnStr;
    }

    public ArrayList<String> printTree(BTNode node, int level) {

        for (int j = 0; j < node.indexSet.size(); j++) { //store all the integers in an array

            wholeTree.set(level, "" + wholeTree.get(level) + node.indexSet.get(j) + " ");
            if (node.pointerList.get(j) != null) //go down the tree
            {
                printTree(node.pointerList.get(j), level + 1);
            }

        }
        //visit the last pointer on the end of the interior node
        if (node.pointerList.get(node.indexSet.size()) != null) {
            printTree(node.pointerList.get(node.indexSet.size()), level + 1);
        }

        wholeTree.set(level, "" + wholeTree.get(level) + " | ");

        return wholeTree;
    }
*/


    
}
