/****************************************************************************************
 * BPTNode.java
 * A node the exists within a B+ Tree.
 *
 *
 * @author William Clements
 * @version March 16 2011
 ***************************************************************************************/

package exe.bplus_tree;
import java.io.*;

import java.util.*;
import exe.pseudocode.*;

public class BPTNode {
      ArrayList<Integer> keyList = new ArrayList<Integer>(); 
      ArrayList<BPTNode> pointerList = new ArrayList<BPTNode>(); 
      BPTNode parentPointer;
      
      //right and left leaf pointers are for the leaves
      BPTNode leftLeaf;
      BPTNode rightLeaf;

      /* node creation
       *
       * @param obj   The object to be put in the node
       */
      public BPTNode(Integer obj) throws IOException { 
        parentPointer = null;
        keyList.add(obj);

        pointerList.add(null);
        pointerList.add(null);

        leftLeaf = null;
        rightLeaf = null;
      }

      public String toString() {
        String returnString = "";
        for (int i=0; i<keyList.size(); i++)
          returnString += keyList.get(i)+" ";
        return returnString; 
      }

      public boolean addToNode(Integer obj, BPTNode rightLeafPointer) throws IOException {

        //linear search. add the number into the list
        for(int i = 0; i < keyList.size(); i++)
        {
          if (obj < keyList.get(i) ) {
            int temp = keyList.get(i);
            BPTNode tempNode = pointerList.get(i+1);

            keyList.set(i,obj);
            pointerList.set(i,rightLeafPointer);
            
            obj = temp;
            rightLeafPointer = tempNode;
          }
        }

        keyList.add(obj);
        pointerList.add(rightLeafPointer);

        return true;
      }

}





