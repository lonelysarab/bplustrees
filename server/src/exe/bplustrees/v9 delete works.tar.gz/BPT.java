/****************************************************************************************
 * BPT.java
 * Representation of a B+ Tree.
 *
 *
 * @author William Clements
 * @version March 16 2011
 ***************************************************************************************/
package exe.bplus_tree;

import java.io.*;
import java.util.*;
import exe.*;

import exe.pseudocode.*;

public class BPT {
  
  public static int minimumCapacity = 2;
  public static int order = 4;
  public ArrayList wholeTree; //helps with printing and debugging the tree
  public static boolean isInDegubbingMode = false;

  /*
   * Constructor makes an object the represents a tree
   */
  public BPT() {
  }

  /*
   * Constructor can insert multiple items into the tree
   * @param numberArray   numbers to be inserted into the tree
   */
  public BPT(Integer[] numberArray) throws IOException {
    for (int i = 0; i < numberArray.length; i++) {
      insert(numberArray[i]);
    }
  }

  /*
   * Deletes a number in the tree
   * @param obj   the integer to be removed
   * @return      true if obj existed and was removed
   */
  public boolean delete(Integer obj) throws IOException {
    snap("delete", 0, obj, 1, PseudoCodeDisplay.YELLOW);
    
    //make your way down the tree
    BPTNode parent = null;
    BPTNode current = BPlusTree.root;

    TreeNode vparent = null;
    TreeNode vcurrent = BPlusTree.visualRoot;

    int index = 0;
    while (current != null) {

      // look through the index set in a node. decide where to go down the tree.
      index = 0;
      while (obj > current.keyList.get(index) && index < current.keyList.size() - 1) {
        index++;
      }

      //move down the tree. choose a direction.
      parent = current;
      if (obj >= parent.keyList.get(index)) //take the pointer to the right of the number
      {
        current = parent.pointerList.get(index + 1);
      } else //take the pointer on the left of the number
      {
        current = parent.pointerList.get(index);
      }

      //the visual tree
      vparent = vcurrent;
      vcurrent = vparent.getChild();
      vparent.setHexColor("#f1f701");
      snap("delete", 0, obj, 6, PseudoCodeDisplay.YELLOW);
      vparent.setHexColor("#eeeeff");
    }

    //parent == leaf node
    if (parent.keyList.get(index) == obj) { //obj is, in fact, in the leaf

      //remove obj from the leaf
      parent.keyList.remove(index);
      parent.pointerList.remove(0); //all these pointers are blank

      // the visual tree
      String nodeString = "";
      for (int i = 0; i < parent.keyList.size(); i++) {
        nodeString += "" + parent.keyList.get(i) + " ";
      }
      vparent.setValue(nodeString);
      vparent.setHexColor("#f1f701");
      snap("delete", 0, obj, 14, PseudoCodeDisplay.YELLOW);
      vparent.setHexColor("#eeeeff");

      //If the number of elements in the leaf falls below minimumCapacity
      //things need to be rearranged. 
      if (parent.keyList.size() < minimumCapacity) {
        
        if (parent.rightLeaf != null && parent.parentPointer != null && parent.parentPointer.keyList.get(0) == parent.rightLeaf.parentPointer.keyList.get(0) && parent.rightLeaf.keyList.size() < minimumCapacity) {
          //distribute elements evenly between two adjacted nodes

          int medianIndex = (int) Math.ceil(((double) parent.keyList.size()) / 2.0);
          for (int i=0; i<medianIndex; i++) {
            parent.addToNode(parent.rightLeaf.keyList.get(0), null);
            parent.rightLeaf.keyList.remove(0);
            parent.rightLeaf.pointerList.remove(0);
          }
          int indexOfKeyForAdjacentLeaf = getIndexInNode(parent.parentPointer,parent.keyList.get(0))+1;
          parent.parentPointer.keyList.set(indexOfKeyForAdjacentLeaf, parent.rightLeaf.keyList.get(0));

          // the visual tree
          nodeString = "";
          for (int i = 0; i < parent.keyList.size(); i++) {
            nodeString += "" + parent.keyList.get(i) + " ";
          }
          vparent.setValue(nodeString);
          vparent.setHexColor("#f1f701");
          snap("delete", 0, obj, 20, PseudoCodeDisplay.YELLOW);
          vparent.setHexColor("#eeeeff");
          nodeString = "";
          for (int i = 0; i < parent.rightLeaf.keyList.size(); i++) {
            nodeString += "" + parent.rightLeaf.keyList.get(i) + " ";
          }
          vparent.getSibling().setValue(nodeString);
          vparent.getSibling().setHexColor("#f1f701");
          snap("delete", 0, obj, 24, PseudoCodeDisplay.YELLOW);
          vparent.getSibling().setHexColor("#eeeeff");
          nodeString = "";
          for (int i = 0; i < parent.parentPointer.keyList.size(); i++) {
            nodeString += "" + parent.parentPointer.keyList.get(i) + " ";
          }
          vparent.getParent().setValue(nodeString);
          vparent.getParent().setHexColor("#f1f701");
          snap("delete", 0, obj, 25, PseudoCodeDisplay.YELLOW);
          vparent.getParent().setHexColor("#eeeeff");

        }else{ //distributing elements cannot be done. there are too few elements. 
          for (int i=0; i<parent.rightLeaf.keyList.size(); i++) {
            parent.addToNode(parent.rightLeaf.keyList.get(i), null);
          }
          int indexOfKeyToRemove = getIndexInNode(parent.parentPointer,parent.keyList.get(0))+1;
          parent.parentPointer.keyList.remove(indexOfKeyToRemove);
          parent.parentPointer.pointerList.remove(indexOfKeyToRemove+1);
          if (parent.rightLeaf.rightLeaf != null) {
            parent.rightLeaf.rightLeaf = parent;
            parent.rightLeaf = parent.rightLeaf.rightLeaf;
          }
          else
            parent.rightLeaf = null;

          // the visual tree
          nodeString = "";
          for (int i = 0; i < parent.keyList.size(); i++) {
            nodeString += "" + parent.keyList.get(i) + " ";
          }
          vparent.setValue(nodeString);
          vparent.setHexColor("#f1f701");
          snap("delete", 0, obj, 30, PseudoCodeDisplay.YELLOW);
          vparent.setHexColor("#eeeeff");
          
        }

      }
    }else{ //obj is not in the leaf

      snap("delete", 0, obj, 41, PseudoCodeDisplay.YELLOW);
      return false;
    }

    snap("delete", 0, obj, 42, PseudoCodeDisplay.YELLOW);
    return true; //successfully deleted
  }

  /*
   * make a snapshot for the visualization
   */
  public void snap(String state, int splitDepth, int x, int line, int color) throws IOException {
    BPlusTree.show.writeSnap(BPlusTree.TITLE, BPlusTree.doc_uri(4), BPlusTree.make_uri(state, splitDepth, x, line, color), BPlusTree.visualTree);
  }

  /*
   * Look for a key in a node. When it is found, return the index.
   * @param node    The node to be searched through
   * @param key     The key that needs to be found
   * @return        The index where the key was found in the node. -1 if not found.
   */
  public int getIndexInNode(BPTNode node, int key) throws IOException {
    int i=node.keyList.size()-1;
    while(i >= 0 && node.keyList.get(i) != key) {
      i--;
    }
    return i;
  }

  /*
   * Inserts a number into the tree
   * @param obj   the integer that is being inserted
   * @return      true if obj did not already exist and was insert
   */
  public boolean insert(Integer obj) throws IOException {

    BPTNode parent = null;
    BPTNode current = BPlusTree.root;

    TreeNode vparent = null;
    TreeNode vcurrent = BPlusTree.visualRoot;

    snap("insert", 0, obj, 1, PseudoCodeDisplay.YELLOW);

    if (BPlusTree.root == null) {
      snap("insert", 0, obj, 2, PseudoCodeDisplay.YELLOW);

      BPlusTree.root = new BPTNode(obj);

      //make the root in the visual tree
      BPlusTree.visualRoot.setValue("" + obj);
      BPlusTree.visualRoot.setHexColor("#f1f701");
      snap("insert", 0, obj, 3, PseudoCodeDisplay.YELLOW);
      BPlusTree.visualRoot.setHexColor("#eeeeff");
    } else {
      snap("insert", 0, obj, 4, PseudoCodeDisplay.YELLOW);

      //traverse down to the leaf
      int index = 0;
      while (current != null) {

        vparent = vcurrent;

        //the visual tree
        vparent.setHexColor("#f1f701");
        snap("insert", 0, obj, 5, PseudoCodeDisplay.YELLOW);
        vparent.setHexColor("#eeeeff");

        // look through the index set in a node. decide where to go down the tree.
        index = 0;
        while (obj > current.keyList.get(index) && index < current.keyList.size() - 1) {
          index++;
        }

        //move down the tree. choose a direction.
        parent = current;

        //the visual tree
        vparent.setHexColor("#f1f701");
        snap("insert", 0, obj, 9, PseudoCodeDisplay.YELLOW);
        vparent.setHexColor("#eeeeff");
        vcurrent = vparent.getChild();

        if (obj >= parent.keyList.get(index)) //take the pointer to the right of the number
        {
          current = parent.pointerList.get(index + 1);
        } else //take the pointer on the left of the number
        {
          current = parent.pointerList.get(index);
        }

      }

      //at this point parent is at a leaf node
      if (parent.keyList.get(index) != obj) { //x is not in the leaf
        //the visual tree
        vparent.setHexColor("#f1f701");
        snap("insert", 0, obj, 15, PseudoCodeDisplay.YELLOW);
        vparent.setHexColor("#eeeeff");

        parent.addToNode(obj, null);

        // the visual tree
        String nodeString = "";
        for (int i = 0; i < parent.keyList.size(); i++) {
          nodeString += "" + parent.keyList.get(i) + " ";
        }
        vparent.setValue(nodeString);
        vparent.setHexColor("#f1f701");
        snap("insert", 0, obj, 16, PseudoCodeDisplay.YELLOW);
        vparent.setHexColor("#eeeeff");

        //the leaf must be split. leaf size cannot = order
        if (parent.keyList.size() == order) {
          snap("insert", 0, obj, 17, PseudoCodeDisplay.YELLOW);
          snap("insert", 0, obj, 18, PseudoCodeDisplay.YELLOW);
          split(parent, vparent);
        }

      } else {
        snap("insert", 0, obj, 21, PseudoCodeDisplay.YELLOW);
        return false; // The integer to be inserted already exists.
      }
    }

    //test print of the root
    System.out.print("current root view: ");
    for (int i = 0; i < BPlusTree.root.keyList.size(); i++) {
      System.out.print(BPlusTree.root.keyList.get(i) + " ");
    }
    System.out.println();

    snap("insert", 0, obj, 23, PseudoCodeDisplay.YELLOW);
    return true;
  }

  /*
   * Splits a node or a leaf within the tree and places the newly created node on the right of the node being split
   * @param currentNodeToBeSplit    The node that is being split
   * @param vcurrentNodeToBeSplit    A duplicate node being split in the BPlusTree class
   */
  public void split(BPTNode currentNodeToBeSplit, TreeNode vcurrentNodeToBeSplit) throws IOException {
    BPlusTree.splitScope++;
    snap("split", BPlusTree.splitScope, 0, 1, PseudoCodeDisplay.YELLOW);

    //Find the median
    int medianIndex = (int) Math.ceil(((double) currentNodeToBeSplit.keyList.size()) / 2.0);
    int median = currentNodeToBeSplit.keyList.get(medianIndex);

    if (currentNodeToBeSplit.pointerList.get(0) == null) { //spliting a leaf
      snap("split", BPlusTree.splitScope, 0, 3, PseudoCodeDisplay.YELLOW);

      //Make a new leaf node. put the median and all the numbers > the median in this node
      BPTNode newLeafNode = new BPTNode(currentNodeToBeSplit.keyList.remove(medianIndex));
      currentNodeToBeSplit.pointerList.remove(medianIndex);
      newLeafNode.parentPointer = currentNodeToBeSplit.parentPointer;
      newLeafNode.rightLeaf = currentNodeToBeSplit.rightLeaf;
      newLeafNode.leftLeaf = currentNodeToBeSplit;
      if (newLeafNode.rightLeaf != null) {
        newLeafNode.rightLeaf.leftLeaf = newLeafNode;
      }
      while (currentNodeToBeSplit.keyList.size() > medianIndex) {
        newLeafNode.addToNode(currentNodeToBeSplit.keyList.remove(medianIndex), null);
        currentNodeToBeSplit.pointerList.remove(medianIndex);
      }

      //Fix the pointers of the leaf that was split
      currentNodeToBeSplit.rightLeaf = newLeafNode;

      //the visual tree
      String nodeString = "";
      for (int i = 0; i < newLeafNode.keyList.size(); i++) {
        nodeString += "" + newLeafNode.keyList.get(i) + " ";
      }
      TreeNode vnewLeafNode = new TreeNode(nodeString);
      vnewLeafNode.setHexColor("#eeeeff");
      vcurrentNodeToBeSplit.setHexColor("#f1f701");
      snap("split", BPlusTree.splitScope, 0, 15, PseudoCodeDisplay.YELLOW);
      vcurrentNodeToBeSplit.setHexColor("#eeeeff");

      if (currentNodeToBeSplit.parentPointer == null) //a new node is made at the root
      {
        snap("split", BPlusTree.splitScope, 0, 16, PseudoCodeDisplay.YELLOW);
        BPTNode newParentNode = new BPTNode(newLeafNode.keyList.get(0));
        newParentNode.pointerList.set(0, currentNodeToBeSplit);
        newParentNode.pointerList.set(1, newLeafNode);
        currentNodeToBeSplit.parentPointer = newParentNode;
        BPlusTree.root = newParentNode;

        //the visual tree
        TreeNode vnewParentNode = new TreeNode("" + newLeafNode.keyList.get(0));
        vnewParentNode.setHexColor("#eeeeff");
        vnewParentNode.setParent(vcurrentNodeToBeSplit.getParent());
        BPlusTree.visualRoot = vnewParentNode;
        BPlusTree.visualTree.setRoot(BPlusTree.visualRoot);
        vnewParentNode.setChildWithEdge(vcurrentNodeToBeSplit);
        vnewParentNode.setChildWithEdge(vnewLeafNode);
        nodeString = "";
        for (int i = 0; i < currentNodeToBeSplit.keyList.size(); i++) {
          nodeString += "" + currentNodeToBeSplit.keyList.get(i) + " ";
        }
        vcurrentNodeToBeSplit.setValue(nodeString);
        snap("split", BPlusTree.splitScope, 0, 23, PseudoCodeDisplay.YELLOW);

      } else // a parent exist. pass a number up to the parent
      {
        snap("split", BPlusTree.splitScope, 0, 25, PseudoCodeDisplay.YELLOW);
        currentNodeToBeSplit.parentPointer.addToNode(newLeafNode.keyList.get(0), newLeafNode);
        snap("split", BPlusTree.splitScope, 0, 27, PseudoCodeDisplay.YELLOW);
        if (currentNodeToBeSplit.parentPointer.keyList.size() == order) {
          snap("split", BPlusTree.splitScope, 0, 28, PseudoCodeDisplay.YELLOW);
          split(currentNodeToBeSplit.parentPointer, vcurrentNodeToBeSplit.getParent());
        }
      }

    } else { //spliting a node
      snap("split", BPlusTree.splitScope, 0, 30, PseudoCodeDisplay.YELLOW);

      //Make a new node. put the median and all the numbers > the median in this node
      BPTNode newNodeOnTheRight = new BPTNode(currentNodeToBeSplit.keyList.remove(medianIndex));
      currentNodeToBeSplit.pointerList.remove(medianIndex);
      newNodeOnTheRight.parentPointer = currentNodeToBeSplit.parentPointer;
      newNodeOnTheRight.rightLeaf = null;
      newNodeOnTheRight.leftLeaf = null;
      while (currentNodeToBeSplit.keyList.size() > medianIndex) {
        newNodeOnTheRight.addToNode(currentNodeToBeSplit.keyList.remove(medianIndex), null);
        currentNodeToBeSplit.pointerList.remove(medianIndex);
      }

      currentNodeToBeSplit.rightLeaf = null;
      currentNodeToBeSplit.leftLeaf = null;

      if (currentNodeToBeSplit.parentPointer == null) { //a new node is made at the root
        BPTNode newParentNode = new BPTNode(newNodeOnTheRight.keyList.get(0));
        newParentNode.pointerList.set(0, currentNodeToBeSplit);
        newParentNode.pointerList.set(1, newNodeOnTheRight);
        currentNodeToBeSplit.parentPointer = newParentNode;
        BPlusTree.root = newParentNode;
      } else { // a parent exist. pass a number up to the parent
        snap("split", BPlusTree.splitScope, 0, 49, PseudoCodeDisplay.YELLOW);
        currentNodeToBeSplit.parentPointer.addToNode(newNodeOnTheRight.keyList.get(0), newNodeOnTheRight);
        snap("split", BPlusTree.splitScope, 0, 51, PseudoCodeDisplay.YELLOW);
        if (currentNodeToBeSplit.parentPointer.keyList.size() == order) {
          snap("split", BPlusTree.splitScope, 0, 52, PseudoCodeDisplay.YELLOW);
          split(currentNodeToBeSplit.parentPointer, vcurrentNodeToBeSplit.getParent());
        }
      }

    }

    BPlusTree.splitScope--;
    return;
  }
}
