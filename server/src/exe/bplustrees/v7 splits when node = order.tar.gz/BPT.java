/****************************************************************************************
 * BPT.java
 * holds the tree
 *
 *
 * @author William Clements
 * @version May 16 2010
 ***************************************************************************************/
package exe.bplus_tree;

import java.io.*;

import java.util.*;
import exe.*;

import exe.pseudocode.*;

public class BPT {

  /**  */
  public BPT() {
  }

  /**  */
  public BPT(Integer[] numberArray) throws IOException {
    for (int i = 0; i < numberArray.length; i++) {
      insert(numberArray[i]);
    }
  }

  /**  */
  public boolean insert(Integer obj) throws IOException {

    BPTNode parent = null;
    BPTNode current = BPlusTree.root;

    TreeNode vparent = null;
    TreeNode vcurrent = BPlusTree.visualRoot;

    if (BPlusTree.root == null) {
      BPlusTree.root = new BPTNode(obj);

      //make the root in the visual tree
      BPlusTree.visualRoot.setValue("" + obj);
      BPlusTree.visualRoot.setHexColor("#eeeeff");
      BPlusTree.show.writeSnap(BPlusTree.TITLE, BPlusTree.doc_uri(4), BPlusTree.make_uri(1, 1, 1, PseudoCodeDisplay.PURPLE), BPlusTree.visualTree);
    } else {

      //traverse down to the leaf
      int index = 0;
      while (current != null) {

        vparent = vcurrent;
        vparent.setHexColor("#f1f701");
        BPlusTree.show.writeSnap(BPlusTree.TITLE, BPlusTree.doc_uri(4), BPlusTree.make_uri(1, 1, 1, PseudoCodeDisplay.GREEN), BPlusTree.visualTree);
        vparent.setHexColor("#eeeeff");

        // look through the index set in a node. decide where to go down the tree.
        index = 0;
        while (obj > current.indexSet.get(index) && index < current.indexSet.size() - 1) {
          index++;
        }

        //move down the tree. choose a direction.
        parent = current;
        if (obj >= parent.indexSet.get(index)) //take the pointer to the right of the number
        {
          current = parent.pointerList.get(index + 1);
        } else //take the pointer on the left of the number
        {
          current = parent.pointerList.get(index);
        }

      }

      //at this point parent is at a leaf node
      if (parent.indexSet.get(index) != obj) {
        parent.addToNode(obj, null);

        // the visual tree
        String nodeString = "";
        for (int i = 0; i < parent.indexSet.size(); i++) {
          nodeString += "" + parent.indexSet.get(i) + " ";
        }
        vparent.setValue(nodeString);
        BPlusTree.show.writeSnap(BPlusTree.TITLE, BPlusTree.doc_uri(4), BPlusTree.make_uri(1, 1, 1, PseudoCodeDisplay.YELLOW), BPlusTree.visualTree);

        //the leaf must be split. leaf size cannot = order
        if (parent.indexSet.size() == BPlusTree.order) {
          split(parent);
        }

      } else {
        return false; // The integer to be inserted already exists.
      }
    }

    //test print of the root
    System.out.print("current root view: ");
    for (int i = 0; i < BPlusTree.root.indexSet.size(); i++) {
      System.out.print(BPlusTree.root.indexSet.get(i) + " ");
    }
    System.out.println();

    return true;
  }

  public void split(BPTNode currentNodeToBeSplit) throws IOException {
    if (currentNodeToBeSplit.pointerList.get(0) == null) { //spliting a leaf

      //Find the median
      int medianIndex = (int) Math.ceil(((double) currentNodeToBeSplit.indexSet.size()) / 2.0);
      int median = currentNodeToBeSplit.indexSet.get(medianIndex);

      //Make a new leaf node. put the median and all the numbers > the median in this node
      BPTNode newLeafNode = new BPTNode(currentNodeToBeSplit.indexSet.remove(medianIndex));
      currentNodeToBeSplit.pointerList.remove(medianIndex);
      newLeafNode.parentPointer = currentNodeToBeSplit.parentPointer;
      newLeafNode.rightLeaf = currentNodeToBeSplit.rightLeaf;
      newLeafNode.leftLeaf = currentNodeToBeSplit;
      if (newLeafNode.rightLeaf != null) {
        newLeafNode.rightLeaf.leftLeaf = newLeafNode;
      }
      while (currentNodeToBeSplit.indexSet.size() > medianIndex) {
        newLeafNode.addToNode(currentNodeToBeSplit.indexSet.remove(medianIndex), null);
        currentNodeToBeSplit.pointerList.remove(medianIndex);
      }

      //Fix the pointers of the leaf that was split
      currentNodeToBeSplit.rightLeaf = newLeafNode;

      if (currentNodeToBeSplit.parentPointer == null) { //a new node is made at the root
        BPTNode newParentNode = new BPTNode(newLeafNode.indexSet.get(0));
        newParentNode.pointerList.set(0, currentNodeToBeSplit);
        newParentNode.pointerList.set(1, newLeafNode);
        currentNodeToBeSplit.parentPointer = newParentNode;
        BPlusTree.root = newParentNode;
      } else { // a parent exist. pass a number up to the parent
        currentNodeToBeSplit.parentPointer.addToNode(newLeafNode.indexSet.get(0), newLeafNode);
        if (currentNodeToBeSplit.parentPointer.indexSet.size() == BPlusTree.order) {
          split(currentNodeToBeSplit.parentPointer);
        }
      }

    } else { //spliting a node

      //Find the median
      int medianIndex = (int) Math.ceil(((double) currentNodeToBeSplit.indexSet.size()) / 2.0);
      int median = currentNodeToBeSplit.indexSet.get(medianIndex);

      //Make a new node. put the median and all the numbers > the median in this node
      BPTNode newNodeOnTheRight = new BPTNode(currentNodeToBeSplit.indexSet.remove(medianIndex));
      currentNodeToBeSplit.pointerList.remove(medianIndex);
      newNodeOnTheRight.parentPointer = currentNodeToBeSplit.parentPointer;
      newNodeOnTheRight.rightLeaf = null;
      newNodeOnTheRight.leftLeaf = null;
      while (currentNodeToBeSplit.indexSet.size() > medianIndex) {
        newNodeOnTheRight.addToNode(currentNodeToBeSplit.indexSet.remove(medianIndex), null);
        currentNodeToBeSplit.pointerList.remove(medianIndex);
      }

      currentNodeToBeSplit.rightLeaf = null;
      currentNodeToBeSplit.leftLeaf = null;

      if (currentNodeToBeSplit.parentPointer == null) { //a new node is made at the root
        BPTNode newParentNode = new BPTNode(newNodeOnTheRight.indexSet.get(0));
        newParentNode.pointerList.set(0, currentNodeToBeSplit);
        newParentNode.pointerList.set(1, newNodeOnTheRight);
        currentNodeToBeSplit.parentPointer = newParentNode;
        BPlusTree.root = newParentNode;
      } else { // a parent exist. pass a number up to the parent
        currentNodeToBeSplit.parentPointer.addToNode(newNodeOnTheRight.indexSet.get(0), newNodeOnTheRight);
        if (currentNodeToBeSplit.parentPointer.indexSet.size() == BPlusTree.order) {
          split(currentNodeToBeSplit.parentPointer);
        }
      }

    }

    return;
  }
  public ArrayList wholeTree;
}
