/****************************************************************************************
 * BPlusTree.java
 * B+ Tree Visualization
 *
 *
 * @author William Clements
 * @version May 16 2010
 ***************************************************************************************/
package exe.bplus_tree;

import java.io.*;
import java.lang.*;
import java.util.*;

import java.net.*;
import org.jdom.*;
import exe.*;
import exe.pseudocode.*;

public class BPlusTree {

    //for JHAVE
    static final String TITLE = null;
    static final String FILE = "exe/bplus_tree/template.xml";
    static PseudoCodeDisplay pseudo;
    static ShowFile show;
    static int order;

    //the trees
    static GAIGSb_plus_tree visualTree;
    static BPT tree;

    //the roots
    static TreeNode visualRoot;
    static BPTNode root;

    public static void main(String args[]) throws IOException {
        // show file creation for the client
        show = new ShowFile(args[0]);

        // Set restrictions on how wide the tree will be
        if (0 < Integer.parseInt(args[1]) && Integer.parseInt(args[1]) < 5) {
          order = Integer.parseInt(args[1]);
        }
        else {
          order = 4;
        }

        // declare a new tree in JHAVE and make a root
        visualTree = new GAIGSb_plus_tree(false, "B+ Tree of order "+order, "#000000", 0.1, 0.1, 0.9, 0.9, 0.07);
        visualRoot = new TreeNode();
        visualTree.setRoot(visualRoot);

        //setup the pseudo code display panel
        try {
            pseudo = new PseudoCodeDisplay(FILE);
        } catch (JDOMException e) {
            e.printStackTrace();
        }

        // initialize tree and add random numbers
        // this tests the tree
        Integer[] tempIntArray = {6,8,5,7};//,4};
        tree = new BPT(tempIntArray);
/*****************************************************tree node examples below

        //assign a value to the root
        visualRoot.setValue("3");
        visualRoot.setHexColor("#eeeeff");
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        //make siblings 
        TreeNode tempNodeOne = new TreeNode();
        tempNodeOne.setValue("1");
        tempNodeOne.setHexColor("#eeeeff");
        visualRoot.setChildWithEdge(tempNodeOne);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        TreeNode tempNodetwo = new TreeNode();
        tempNodetwo.setValue("2");
        tempNodetwo.setHexColor("#eeeeff");
        visualRoot.setChildWithEdge(tempNodetwo);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        TreeNode tempNodeThree = new TreeNode();
        tempNodeThree.setValue("3");
        tempNodeThree.setHexColor("#eeeeff");
        visualRoot.setChildWithEdge(tempNodeThree);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        TreeNode tempNodeFour = new TreeNode();
        tempNodeFour.setValue("4");
        tempNodeFour.setHexColor("#eeeeff");
        visualRoot.setChildWithEdge(tempNodeFour);
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);

        visualRoot.getChild().setHexColor("#f1f701");
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);
        visualRoot.getChild().getSibling().setHexColor("#f1f701");
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);


        visualRoot.setChild(visualRoot.getChild().getSibling());
        show.writeSnap(TITLE, doc_uri(4), make_uri(1, 1, 1, PseudoCodeDisplay.RED), visualTree);



*/    
        show.close();
    }


    public static String make_uri(int pass, int i, int line, int color) {
        return make_uri(pass, i, new int[]{line}, new int[]{color});
    }

    public static String make_uri(int pass, int i, int[] lines, int[] colors) {
        String passVal = pass == -1 ? "null" : String.valueOf(pass);
        String iVal = i == -1 ? "null" : String.valueOf(i);
        String stack = "main program\n"+"  insert(integer)";

        HashMap<String, String> map = new HashMap<String, String>();
        map.put("s", stack);
      	map.put("i", iVal);
      	map.put("s", stack);

        String uri = null;
        try {
            uri = pseudo.pseudo_uri(map, lines, colors);
        } catch (JDOMException e) {
            e.printStackTrace();
        }

        return uri;
    }

    // Return an appropriate inline string for the info page
    public static String doc_uri(int num_items) {

        String content = "<html><head><title>B+ Tree</title></head><body><h1>B+ Tree</h1></body></html>";
        URI uri = null;
        try {
            uri = new URI("str", content, "");
        } catch (java.net.URISyntaxException e) {
        }
        return uri.toASCIIString();
    }

    
}
