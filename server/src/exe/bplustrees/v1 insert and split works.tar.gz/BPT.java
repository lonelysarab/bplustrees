/****************************************************************************************
 * BPT.java
 * Implements a B+ Tree
 *
 *
 * @author William Clements
 * @version March 16 2010
 ***************************************************************************************/
import java.util.ArrayList;

public class BPT {
  private BPTNode root;
  int order = 4;  

  /**  */
  public BPT() {
  }

  /**  */
  public BPT(Integer[] numberArray) {
    for (int i = 0; i < numberArray.length; i++)
      insert(numberArray[i]);
  }

  /**  */
  public boolean insert(Integer obj) {

    BPTNode parent = null;
    BPTNode current = root;

    if (root == null)
      root = new BPTNode(obj); 
    else {

      //traverse down to the leaf
      int index = 0;
      while (current != null) {

        // look through the index set in a node
        index = 0;

        while(obj > current.indexSet.get(index) && index < current.indexSet.size()-1) {
          index++;
        }

        //searching down the tree, choose a direction
        parent = current;

        if(obj >= parent.indexSet.get(index))
          current = parent.pointerList.get(index+1);
        else //go to the left
          current = parent.pointerList.get(index);
      }

      //at this point parent is at a leaf node

      if (parent.indexSet.get(index) != obj) {
        if (parent.indexSet.size() < order) // there is room to insert number in the leaf
          parent.addToNode(obj,null);
        else { //the leaf must be split after insertion. leaf size cannot = order.
          parent.addToNode(obj,null);          
          split(parent);
        }
      }
      else 
        return false; // The integer to be inserted already exists.

    }

    //test print of the root
    System.out.print("current root view: ");
    for(int i=0; i<root.indexSet.size(); i++)
      System.out.print(root.indexSet.get(i)+" ");
    System.out.println();

    return true; 
  }

  public void split(BPTNode currentNodeToBeSplit) {
    if (currentNodeToBeSplit.pointerList.get(0) == null) { //spliting a leaf 

      //Find the median
      int medianIndex=(int)Math.ceil(((double)currentNodeToBeSplit.indexSet.size())/2.0);

      int median = currentNodeToBeSplit.indexSet.get(medianIndex);

      //Make a new leaf node. put the median and all the numbers > the median in this node
      BPTNode newLeafNode = new BPTNode(currentNodeToBeSplit.indexSet.remove(medianIndex));
      currentNodeToBeSplit.pointerList.remove(medianIndex);
      newLeafNode.parentPointer = currentNodeToBeSplit.parentPointer;
      newLeafNode.rightLeaf = currentNodeToBeSplit.rightLeaf;
      newLeafNode.leftLeaf = currentNodeToBeSplit;
      if (newLeafNode.rightLeaf != null)
        newLeafNode.rightLeaf.leftLeaf = newLeafNode;
      while(currentNodeToBeSplit.indexSet.size() > medianIndex) {
        newLeafNode.addToNode(currentNodeToBeSplit.indexSet.remove(medianIndex),null);
        currentNodeToBeSplit.pointerList.remove(medianIndex);
      }

      //Fix the pointers of the leaf that was split
      currentNodeToBeSplit.rightLeaf = newLeafNode;

      if (currentNodeToBeSplit.parentPointer == null) { //a new node is made at the root
        BPTNode newParentNode = new BPTNode(newLeafNode.indexSet.get(0));
        newParentNode.pointerList.set(0,currentNodeToBeSplit);
        newParentNode.pointerList.set(1,newLeafNode);
        currentNodeToBeSplit.parentPointer = newParentNode;
        root = newParentNode;
      }
      else { // a parent exist. pass a number up to the parent
        currentNodeToBeSplit.parentPointer.addToNode(newLeafNode.indexSet.get(0),newLeafNode);
        if (currentNodeToBeSplit.parentPointer.indexSet.size() == order)
          split(currentNodeToBeSplit.parentPointer);
      }

    }
    else { //spliting a node
      
      //Find the median
      int medianIndex=(int)Math.ceil(((double)currentNodeToBeSplit.indexSet.size())/2.0);

      int median = currentNodeToBeSplit.indexSet.get(medianIndex);

      //Make a new node. put the median and all the numbers > the median in this node
      BPTNode newNodeOnTheRight = new BPTNode(currentNodeToBeSplit.indexSet.remove(medianIndex));
      currentNodeToBeSplit.pointerList.remove(medianIndex);
      newNodeOnTheRight.parentPointer = currentNodeToBeSplit.parentPointer;
      newNodeOnTheRight.rightLeaf = null;
      newNodeOnTheRight.leftLeaf = null;
      while(currentNodeToBeSplit.indexSet.size() > medianIndex) {
        newNodeOnTheRight.addToNode(currentNodeToBeSplit.indexSet.remove(medianIndex),null);
        currentNodeToBeSplit.pointerList.remove(medianIndex);
      }

      currentNodeToBeSplit.rightLeaf = null;
      currentNodeToBeSplit.leftLeaf = null;

      if (currentNodeToBeSplit.parentPointer == null) { //a new node is made at the root
        BPTNode newParentNode = new BPTNode(newNodeOnTheRight.indexSet.get(0));
        newParentNode.pointerList.set(0,currentNodeToBeSplit);
        newParentNode.pointerList.set(1,newNodeOnTheRight);
        currentNodeToBeSplit.parentPointer = newParentNode;
        root = newParentNode;
      }
      else { // a parent exist. pass a number up to the parent
        currentNodeToBeSplit.parentPointer.addToNode(newNodeOnTheRight.indexSet.get(0),newNodeOnTheRight);
        if (currentNodeToBeSplit.parentPointer.indexSet.size() == order)
          split(currentNodeToBeSplit.parentPointer);
      }

    }

    return;
  } 

  public ArrayList wholeTree;

  public String printTree() {
  
    //find depth
    int level = 0;
    BPTNode tempNode = root;
    wholeTree = new ArrayList<String>();

    while (tempNode != null) {
      wholeTree.add(level,"");
      tempNode = tempNode.pointerList.get(0);
      level++;
    }
    System.out.println("levels present: "+level);

    ArrayList<String> treeArray = printTree(root,0);

    String rtnStr = "";
    for(int i=0; i<treeArray.size(); i++)
      rtnStr += treeArray.get(i)+"\n";
    return rtnStr; 
  }

  public ArrayList<String> printTree(BPTNode node, int level) {

    for (int j=0; j < node.indexSet.size(); j++) { //store all the integers in an array

      wholeTree.set(level,"" + wholeTree.get(level) + node.indexSet.get(j) + " ");
      if (node.pointerList.get(j) != null) //go down the tree
        printTree(node.pointerList.get(j),level+1);

    }
    //visit the last pointer on the end of the interior node
    if (node.pointerList.get(node.indexSet.size()) != null) 
      printTree(node.pointerList.get(node.indexSet.size()),level+1);

    wholeTree.set(level,""+wholeTree.get(level)+" | ");

    return wholeTree;
  }

  private static class BPTNode {
    ArrayList<Integer> indexSet = new ArrayList<Integer>(); //contain integers
    ArrayList<BPTNode> pointerList = new ArrayList<BPTNode>(); 
    BPTNode parentPointer;
    
    //right and left leaf pointers are for the leaves
    BPTNode leftLeaf;
    BPTNode rightLeaf;

    public BPTNode(Integer obj) { //the first integer that goes into the root
      parentPointer = null;
      indexSet.add(obj);
      pointerList.add(null);
      pointerList.add(null);
      leftLeaf = null;
      rightLeaf = null;
    }

    public String toString() {
      String returnString = "";
      for (int i=0; i<indexSet.size(); i++)
        returnString += indexSet.get(i)+" ";
      return returnString; 
    }

    public boolean addToNode(Integer obj, BPTNode rightLeafPointer) {

      //linear search. add the number into the list
      for(int i = 0; i < indexSet.size(); i++)
      {
        if (obj < indexSet.get(i) ) {
          int temp = indexSet.get(i);
          BPTNode tempNode = pointerList.get(i+1);

          indexSet.set(i,obj);
          pointerList.set(i,rightLeafPointer);
          
          obj = temp;
          rightLeafPointer = tempNode;
        }
      }

      indexSet.add(obj);
      pointerList.add(rightLeafPointer);

      return true;
    }

  }

}


