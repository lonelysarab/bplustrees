/****************************************************************************************
 * TestBPT.java
 * Driver to test BPlusTree.java
 *
 * @author William Clements
 * @version March 16 2010
 ***************************************************************************************/
public class TestBPT {
  public static void main(String[] args) 
  {
    Integer[] tempIntArray = {6,8,5,7,4};
    BPT tree = new BPT(tempIntArray);
    System.out.println("Print out of tree: \n"+tree.printTree() );    
  }
}

