/****************************************************************************************
 * BPTNode.java
 * holds the nodes
 *
 *
 * @author William Clements
 * @version May 16 2010
 ***************************************************************************************/

package exe.bplus_tree;
import java.io.*;

import java.util.*;
import exe.pseudocode.*;

public class BPTNode {
      ArrayList<Integer> indexSet = new ArrayList<Integer>(); //contain integers
      ArrayList<BPTNode> pointerList = new ArrayList<BPTNode>(); 
      BPTNode parentPointer;
      
      //right and left leaf pointers are for the leaves
      BPTNode leftLeaf;
      BPTNode rightLeaf;

      /* node creation
       *
       * @param obj   The object to be put in the node
       */
      public BPTNode(Integer obj) throws IOException { 
        parentPointer = null;
        indexSet.add(obj);

        pointerList.add(null);
        pointerList.add(null);

        leftLeaf = null;
        rightLeaf = null;
      }

      public String toString() {
        String returnString = "";
        for (int i=0; i<indexSet.size(); i++)
          returnString += indexSet.get(i)+" ";
        return returnString; 
      }

      public boolean addToNode(Integer obj, BPTNode rightLeafPointer) throws IOException {

        //linear search. add the number into the list
        for(int i = 0; i < indexSet.size(); i++)
        {
          if (obj < indexSet.get(i) ) {
            int temp = indexSet.get(i);
            BPTNode tempNode = pointerList.get(i+1);

            indexSet.set(i,obj);
            pointerList.set(i,rightLeafPointer);
            
            obj = temp;
            rightLeafPointer = tempNode;
          }
        }

        indexSet.add(obj);
        pointerList.add(rightLeafPointer);

        // the visual tree 
        String nodeString = "";
        for (int i=0; i<indexSet.size(); i++) 
        {
          nodeString += ""+indexSet.get(i)+" ";
        }
//        BPlusTree.visualRoot.setValue(nodeString);
//        BPlusTree.visualRoot.setHexColor("#eeeeff");
//        BPlusTree.show.writeSnap(BPlusTree.TITLE, BPlusTree.doc_uri(4), BPlusTree.make_uri(1, 1, 1, PseudoCodeDisplay.GREEN), BPlusTree.visualTree);

        return true;
      }

}





